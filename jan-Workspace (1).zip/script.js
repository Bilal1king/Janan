const lockScreen = document.getElementById("lockScreen");
const loveScreen = document.getElementById("loveScreen");
const passwordInput = document.getElementById("password");
const error = document.getElementById("error");
const popup = document.getElementById("popup");
const rain = document.getElementById("rain");

let unlocked = false;

// Rain effect
for (let i = 0; i < 90; i++) {
  const drop = document.createElement("span");
  drop.className = "drop";
  drop.style.left = Math.random() * 100 + "%";
  drop.style.animationDuration = (0.5 + Math.random() * 1.2) + "s";
  drop.style.animationDelay = Math.random() * 3 + "s";
  rain.appendChild(drop);
}

// Password lock
document.getElementById("lockForm").addEventListener("submit", function(e) {
  e.preventDefault();

  if (unlocked) return;

  if (passwordInput.value === "2452") {
    unlocked = true;
    lockScreen.classList.add("hidden");
    loveScreen.classList.remove("hidden");
    popup.classList.remove("hidden");
    passwordInput.value = "";
    startHearts();
  } else {
    error.textContent = "Wrong password! Try again ❤️";
    passwordInput.value = "";
    passwordInput.focus();
  }
});

// Romantic popup
document.getElementById("surpriseBtn").addEventListener("click", function() {
  popup.classList.remove("hidden");
  burstHearts();
});

document.getElementById("closePopup").addEventListener("click", function() {
  popup.classList.add("hidden");
});

popup.addEventListener("click", function(e) {
  if (e.target === popup) {
    popup.classList.add("hidden");
  }
});

// Floating hearts
function createHeart() {
  const heart = document.createElement("span");
  heart.className = "love-float";
  heart.textContent = ["❤️", "💖", "💕", "🌹", "💗"][
    Math.floor(Math.random() * 5)
  ];

  heart.style.left = Math.random() * 95 + "%";
  heart.style.fontSize = (18 + Math.random() * 25) + "px";
  document.body.appendChild(heart);

  setTimeout(() => heart.remove(), 4000);
}

let heartTimer;

function startHearts() {
  if (heartTimer) return;
  heartTimer = setInterval(createHeart, 350);
}

function burstHearts() {
  for (let i = 0; i < 25; i++) {
    setTimeout(createHeart, i * 70);
  }
}